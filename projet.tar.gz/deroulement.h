/* Victorien Blanchard et Yann Pascoet */
#ifndef DEROULEMENT_H
#define DEROULEMENT_H
struct Joueur{
	int position_x;
	int position_y;
	int ia;
	char sprite[250];
} Joueur;
int dep_nb_case_possibles(int tab[][9], int taille_tableau, int pos_x, int pos_y);

int verification_case(int tab[][9], int position_x, int position_y);

int case_cliquee(int taille_case, int mouse_pos_x, int mouse_pos_y, int* clic_x, int* clic_y);

void deplacement_joueur(int tab[][9], int* pos_x, int* pos_y, int pos_xx, int pos_yy);

int deplacement_verification(int tab[][9], int pos_x, int pos_y, int* pos_xx, int* pos_yy);

#endif
