#ifndef PARTIE
#define PARTIE

typedef struct Joueur{
	int position_x;
	int position_y;
	int ia_ou_joueur;
	int nombre_de_cases_libres;
	int numero;
} Joueur;

int partie(int taille_tableau, int nombre_joueurs, int nombre_de_joueurs_ia, int tab_succes_debloques[]);

#endif
