#ifndef MENU_H
#define MENU_H

int menu(int* taille_tableau,int* selection, int tableau_succes[]);

void souris_succes(void);
void souris_histoire(void);


#endif
