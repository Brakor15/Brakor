#ifndef MENU_H
#define MENU_H

int menu(int* taille_tableau,int* selection);

#endif
