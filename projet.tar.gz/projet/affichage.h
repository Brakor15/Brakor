/* Victorien Blanchard et Yann Pascoet */
#ifndef AFFICHAGE_H
#define AFFICHAGE_H

void initialisation_jeu(int tab[][9], int* taille_case, int taille_tableau, int* sp_mur_normal, int* sp_bord_gauche, int* sp_bord_droit, int* sp_bord_haut, int* sp_bord_bas);

void g_affichage_plateau(int const tab[][9], int taille_case, int taille_tableau, int phase_de_jeu, int sprite_mur, int sp_bord_gauche, int sp_bord_droit,int sp_bord_haut,int sp_bord_bas);

double arrondi(double value, int digits);

void g_affichage_achivment(int tab_succes_debloques[]);

void decharger_tous_sprites(int sprite_mur, int sp_bord_gauche, int sp_bord_droit,int sp_bord_haut,int sp_bord_bas);

#endif
