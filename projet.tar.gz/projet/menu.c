/*Victorien Blanchard et Yann Pascoet*/
#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include "menu.h"
#include "affichage.h"
#include "histoire.h"

#define LARGEUR_FENETRE 800
#define LONGUEUR_FENETRE 800
#define SELECTION_UN_JOUEUR 1
#define SELECTION_DEUX_JOUEURS 2
#define SELECTION_HISTOIRE 3
#define SELECTION_SUCCES 4
#define SELECTION_RESET 5
#define SELECTION_QUITTER 6

/*Affiche le menu sans aucune surbrillance*/
void souris_normale(int* taille_tableau){
  int selection_image = ChargerSprite("images/selection.png");
  char texte_grille[50];
  sprintf(texte_grille,"images/textes/%dx%d.PNG",*taille_tableau,*taille_tableau);
  
  ChargerImage("images/Titre.PNG",250,50,0,0,300,300);
  ChargerImage("images/Boutons/1joueur.PNG",250,130,0,0,300,50); /*1joueur*/
  ChargerImage("images/Boutons/2joueurs.PNG",250,205,0,0,300,50);/*2*/
  ChargerImage("images/Boutons/Histoire.PNG",250,280,0,0,300,50);/*Mode histoire*/
  ChargerImage("images/Boutons/Achievements.PNG",250,355,0,0,300,50);/*Afficher succes*/
  ChargerImage("images/Boutons/Reset.PNG",250,430,0,0,300,50);/*Reset succes*/
  ChargerImage("images/Boutons/Quitter.PNG",250,505,0,0,300,50);/*Quitter*/

  AfficherSprite(selection_image, 200,600);
  ChargerImage(texte_grille,300,600,0,0,300,300);
  LibererSprite(selection_image);
}
/* Surbrillance bouton 1 joueur*/
void souris_un(void){
  ChargerImage("images/Boutons/1joueur_survol.png",250,130,0,0,350,75);
}
/*Surbrillance bouton 2 joueurs*/
void souris_deux(void){
  ChargerImage("images/Boutons/2joueurs_survol.png",250,205,0,0,350,75);
}
/*Surbrillance bouton Reset*/
void souris_trois(void){
  ChargerImage("images/Boutons/Reset_survol.png",250,430,0,0,350,75);/*Reset succes*/
}

void souris_succes(void){
  ChargerImage("images/Boutons/Achievements_survol.png",250,355,0,0,350,75);/*Afficher succes*/
}

void souris_histoire(void){
  ChargerImage("images/Boutons/Histoire_survol.PNG",250,280,0,0,350,75);/*Mode histoire*/
}

void souris_quitter(void){
  ChoisirCouleurDessin(CouleurParComposante(200,200,0));
  ChargerImage("images/Boutons/Quitter_survol.PNG",250,505,0,0,350,75);/*Quitter*/
  ChoisirCouleurDessin(CouleurParComposante(0,0,0));
}


void reset_achivements(){
  FILE *achiv_file, *save_file;
  int zero = 0;
  achiv_file = fopen("achievements.txt", "w+");
  printf("Remise à 0 du fichier des succès %d%c%d \n", 0, ' ', 0);
  fprintf(achiv_file, "0 0");
  fclose(achiv_file);
  save_file=fopen("histoire/save", "w");
  printf("Remise à 0 des sauvegardes\n");
  fwrite(&zero, 4, 1, save_file);
  fclose(save_file);
}

/*Affiche un menu de sélection du nombre de joueurs et gère les choix effectués*/

int menu(int* taille_tableau,int* selection, int tableau_succes[]){

  int souris_x,souris_y, selection_image;
  *taille_tableau = 3;
  *selection = 0;
  ChargerImageFond("images/Fond_menu.png");
  ChargerImage("images/Titre.PNG",250,50,0,0,300,300);
  selection_image = ChargerSprite("images/selection.png");
  AfficherSprite(selection_image, 200,600);
  /*  ChargerImage("images/textes/3x3.PNG",250,600,0,0,300,300);*/
  souris_normale(taille_tableau);


  while(1){
    while (!SourisCliquee()){
      SourisPosition();
      souris_x=_X;
      souris_y=_Y;
      if((250<=souris_x) && (souris_x<=550) && (130<=souris_y) && (souris_y<=180)){
        souris_un();
        *selection = 1;
      }

      else if((250<=souris_x) && (souris_x<=550) && (205<=souris_y) && (souris_y <= 255)){
        souris_deux();
        *selection = 2;
      }
      else if((250<=souris_x) && (souris_x<=550) && (280<=souris_y) && (souris_y <= 330)){
        souris_histoire();
        *selection = 3;
      }
      else if((250<=souris_x) && (souris_x<=550) && (355<=souris_y) && (souris_y<=405)){
        souris_succes();
        *selection = 4;
      }
      else if((250<=souris_x) && (souris_x<=550) && (430<=souris_y) && (souris_y<=480)){
        souris_trois();
        *selection = 5;
      }
      else if((250<=souris_x) && (souris_x<=550) && (505<=souris_y) && (souris_y<=550)){
        souris_quitter();
        *selection = 6;
      }
      else{
        souris_normale(taille_tableau);
        *selection = 0;
      }

      if (ToucheEnAttente()){ /*Si on appuis sur Echap pendant le prog, ca quitte*/
        if (Touche() == XK_Escape){
          FermerGraphique();
          exit(0);
        }
      }
    }


    if((souris_x>=200) && (souris_x<=300) && (souris_y>=600)){
      if (*taille_tableau > 3){
        *taille_tableau += -1;
        printf("%d\n", *taille_tableau);
      }
    }
    if((souris_x>=500) && (souris_x<=600) && (souris_y>=600)){
      if (*taille_tableau < 9){
        *taille_tableau += +1;
        printf("%d\n", *taille_tableau);
      }
    }
    if (*selection == 1)
      return;
    if (*selection == 2)
      return;
    if (*selection == SELECTION_HISTOIRE){
      return;
    }
    if (*selection == SELECTION_SUCCES){
      printf("Achivement_ouvert\n");
      g_affichage_achivment(tableau_succes);
      ChargerImage("images/croix.png",0,0,0,0,70,70);
      while(1){
        if(SourisCliquee()){
          souris_x = _X;
          souris_y = _Y;
          if(souris_x<=70 && souris_y<=70){
	    ChargerImageFond("images/Fond_menu.PNG");
            souris_normale(taille_tableau);
            printf("Achivement_fermé\n");
            break;
          }
        }
      }
      ChargerImageFond("images/Fond_menu.png");
    }

    if (*selection == 6)
      return;
    if (*selection == 5)
      reset_achivements();


  }
}

void ecran_fin(int victoire){
  ChargerImage("images/Boutons/Recommencer.PNG",250,300,0,0,300,50);
  ChargerImage("images/Boutons/Menu.PNG",250,400,0,0,300,50);
  ChargerImage("images/textes/Gagne.PNG",350,150,200,0,400,300);
  if(victoire==0){
    ChargerImage("images/joueur2_perso.png",250,120,0,0,80,83);
  }else if(victoire==1){
    ChargerImage("images/joueur1_perso.png",250,120,0,0,80,83);
  }

}

void choix_fin(int *choice,int victoire){
  *choice=0;
  ChargerImageFond("images/Fond_menu.png");
  ecran_fin(victoire);

  while(1){
    while(!SourisCliquee()){
      SourisPosition();

      if((_X>=250 && _X<=550) && (_Y>=300 && _Y<=350)){
        ChargerImage("images/Boutons/Recommencer_survol.PNG",250,300,0,0,300,50);
	*choice = 4;
      }

      else if((_X>=250 && _X<=550) && (_Y>=400 && _Y<=450)){
        ChargerImage("images/Boutons/Menu_survol.PNG",250,400,0,0,300,50);
	*choice = 5;
      }
      else{
	ecran_fin(victoire);
	*choice = 0;
      }
    }

    if(*choice==4){
      return;
    }
    if(*choice==5){
      return;
    }
  }
}
