/* Victorien Blanchard et Yann Pascoet*/
#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include "partie.h"
#include "menu.h"

#define MAX 9
#define LARGEUR_FENETRE 800
#define LONGUEUR_FENETRE 800

/*Affichage console, sera retiré */
void print_board(int tab[][9], int taille_tableau){
  int i,z,victoire;

  for(i=0; i<taille_tableau; i++){
    for(z=0; z<taille_tableau; z++){
      if (tab[z][i] == 0)
	printf("0");
      else{
	printf("%d", tab[z][i]);
      }
    }
    putchar('\n');
  }
  putchar('\n');
}



int main(void){
  int taille_tableau = MAX, selection = 0, tab_succes_debloques[3] = {0};
  int victoire,choice;
  InitialiserGraphique();
  CreerFenetre(150,150,LARGEUR_FENETRE,LONGUEUR_FENETRE);
  ChoisirTitreFenetre("Cul de chouette");

  while(1){
    menu(&taille_tableau, &selection, tab_succes_debloques);
    choice=0;
    while(choice!=5){
      if (selection == 1)
	victoire = partie(taille_tableau, 2, 1, tab_succes_debloques);
      if (selection == 2)
	victoire = partie(taille_tableau, 2, 0, tab_succes_debloques);
      if (selection == 3){
	victoire = lancer_histoire(tab_succes_debloques);
      }
      choix_fin(&choice,victoire);
    }
  }
  return EXIT_SUCCESS;
}
