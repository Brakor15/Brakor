#include<stdlib.h>
#include<stdio.h>
#include<graph.h>
#include<math.h>
#include<time.h>
#include <unistd.h>
#include"affichage.h"
#include"achievements.h"
#include"deroulement.h"

#define TAILLE_TERRAIN_DE_JEU 3
#define MAX 9
#define LARGEUR_FENETRE 800
#define LONGUEUR_FENETRE 800
#define JOUEUR_PAS_ENCORE_PLACE -1
#define PLACEMENT_JOUEUR_UN 14
#define PLACEMENT_JOUEUR_DEUX 18
#define PHASE_COCHER_CASE1 11
#define PHASE_DEP_JOUEUR1 1
#define PHASE_DEP_JOUEUR2 2
#define PHASE_COCHER_CASE2 22
#define PHASE_GAME_OVER_JOUEUR_1 -4
#define PHASE_GAME_OVER_JOUEUR_2 -8
#define PHASE_GAME_OVER_EGALITE -48
#define FIN_DEPLACEMENT 1
#define DEPLACEMENT_POSSIBLE 0

/*Affichage console, sera retiré */
void print_board(int tab[][9], int taille_tableau){
  int i,z;

  for(i=0; i<taille_tableau; i++){
    for(z=0; z<taille_tableau; z++){
      if (tab[z][i] == 0)
	printf("0");
      else{
	printf("%d", tab[z][i]);
      }
    }
    putchar('\n');
  }
  putchar('\n');
}

int main(void){
  int taille_tableau = MAX, selection = 0, cross, test, tab[MAX][MAX], i, z, taille_case, clic_x, clic_y, test_deplacement, game_over_joueur1 = 1, game_over_joueur2 = 1;
  int tour_de_jeu = 1, phase_de_jeu = PLACEMENT_JOUEUR_UN, joueur1_x = JOUEUR_PAS_ENCORE_PLACE, joueur1_y = JOUEUR_PAS_ENCORE_PLACE, joueur2_x = JOUEUR_PAS_ENCORE_PLACE, joueur2_y = JOUEUR_PAS_ENCORE_PLACE;
  int pause = 0, sprite_fond_achiv, sprite_achiv_1, achiv_unlocked[3] = {0};


  int sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas; /*Sprites */

  menu(&taille_tableau, &selection);
  initialisation_jeu(tab, &taille_case, taille_tableau, &sp_mur_normal, &sp_bord_gauche, &sp_bord_droit, &sp_bord_haut, &sp_bord_bas); /*On initialise le tableau en fonction de la taille_tableau choisit par l'utilisateur lors du menu */
  sprite_fond_achiv = ChargerSprite("fond_achiv3.png");
  sprite_achiv_1 = ChargerSprite("images/achiv_1.png");
  print_board(tab, taille_tableau); /*Affichage en console pour debeugage*/
  g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu, sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */
  printf("%d", taille_case);
  while(1){
    /* Affiche un carré d'une case pour chaque "0" dans le tableau, et devra afficher une croix pour chaque "1" dans le tableau */
    if (SourisCliquee()){
      SourisPosition();
      case_cliquee(taille_case, _X, _Y, &clic_x, &clic_y); /*On stocke la valeurs des cases cliquees en X et en Y dans les variables clic_x et clic_y*/
      test = verification_case(tab, clic_x, clic_y); /*On verifie si la case n'est pas deja à "1" */


      switch(phase_de_jeu){

      case PLACEMENT_JOUEUR_UN: /* Si elle était vide, on la remplis par une croix, un "1"*/
	printf("Placement du joueur 1\n");
	tab[clic_x][clic_y] = 4;
	joueur1_x = clic_x;
	joueur1_y = clic_y;
	phase_de_jeu = PLACEMENT_JOUEUR_DEUX;
	break;

      case PLACEMENT_JOUEUR_DEUX:
	if (test == 0){ /* */
	  printf("Placement du joueur 2\n");
	  tab[clic_x][clic_y] = 8;
	  joueur2_x = clic_x;
	  joueur2_y = clic_y;
	  phase_de_jeu = PHASE_DEP_JOUEUR1;
	}
	break;

	/*Partie où les joueurs déplacent leur pions */
      case PHASE_DEP_JOUEUR1:
	if (test == 0){ /* Si la case cliquee libre et phase dep joueur, on deplace le joueur en fonction du tour*/
	  test_deplacement = deplacement_verification(tab, &joueur1_x, &joueur1_y, clic_x, clic_y);
	  if (test_deplacement == DEPLACEMENT_POSSIBLE){
	    deplacement_joueur(tab, &joueur1_x, &joueur1_y, clic_x, clic_y);
	    phase_de_jeu = PHASE_COCHER_CASE1;
	    test_deplacement = FIN_DEPLACEMENT;
	  }
	}
	break;

      case PHASE_DEP_JOUEUR2:
	if (test == 0){
	  test_deplacement = deplacement_verification(tab, &joueur2_x, &joueur2_y, clic_x, clic_y);
	  if (test_deplacement == DEPLACEMENT_POSSIBLE){
	    deplacement_joueur(tab, &joueur2_x, &joueur2_y, clic_x, clic_y);
	    phase_de_jeu = PHASE_COCHER_CASE2;
	    test_deplacement = FIN_DEPLACEMENT;
	  }
	}
	break;

	/*Partie où les joueurs cochent des cases */
      case PHASE_COCHER_CASE1:
	if (test == 0){
	  tab[clic_x][clic_y] = 1;
	  phase_de_jeu = PHASE_DEP_JOUEUR2;
	}
	break;
      case PHASE_COCHER_CASE2:
	if (test == 0){
	  tab[clic_x][clic_y] = 1;
	  phase_de_jeu = PHASE_DEP_JOUEUR1;
	}
	break;
	break;
      }


      g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu,
			  sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */
      printf("Tour du joueur %d, Phase de jeu = %d \n", tour_de_jeu, phase_de_jeu);
      print_board(tab, taille_tableau);/*Affichage console pour débeugage*/

      if (phase_de_jeu != PLACEMENT_JOUEUR_DEUX){
	game_over_joueur1 = dep_nb_case_possibles(tab, taille_tableau, &joueur1_x, &joueur1_y);
	printf("nb_cases_dispo_apres_fn1 %d\n", game_over_joueur1);
	game_over_joueur2 = dep_nb_case_possibles(tab, taille_tableau, &joueur2_x, &joueur2_y);
	printf("nb_cases_dispo_apres_fn2 %d\n", game_over_joueur2);
      }


      if (game_over_joueur1 == 0 && phase_de_jeu == PHASE_DEP_JOUEUR2 && game_over_joueur2 != 0){ /*On débloque le succès suicide*/
	debloquer_succes(1, achiv_unlocked);
	printf("Succes suicide");
      }
      if(game_over_joueur1 == 0 && phase_de_jeu == PHASE_DEP_JOUEUR1){
	printf("%d\n", phase_de_jeu);
	printf("GAME OVER JOUEUR 1\n");
	return 1;
      }

      else if(game_over_joueur2 == 0 && phase_de_jeu == PHASE_DEP_JOUEUR2){
	debloquer_succes(2, achiv_unlocked);
	printf("GAME OVER JOUEUR 2\n");
	return 1;
      }

    }

    if (ToucheEnAttente()){
      if(Touche() == XK_Escape){ /*Si on appuis sur Echap pendant le prog, ca quitte*/
	FermerGraphique();
	return EXIT_SUCCESS;
      }
      else{
	printf("Achivement_ouvert\n");

	g_affichage_achivment(sprite_fond_achiv, achiv_unlocked);
	while(1){
	  if(Touche()){
	    ChargerImage("images/fond.png",0,0,0,0,800,800);
	    g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu, sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */
	    break;
	  }
	}
	printf("Achivement_fermé\n");

      }
    }

    /*CREER FONCTION POUR QUITTER QUI DECHARGE LES SPRITES*/
  }
  return EXIT_SUCCESS;
}
