/* Victorien Blanchard et Yann Pascoet */
#ifndef ACHIEVEMENTS_H
#define ACHIEVEMENTS_H

int verification_achivement_deja_unlocked(int achivement_unlocked, int tableau_achivement[]);

void g_gagner_achiv(int numero_achiv, int achivement_unlocked[]);
void afficher_succes(int numero_achiv);

void debloquer_succes(int achivement_unlocked, int tableau_achivement[]);

#endif
