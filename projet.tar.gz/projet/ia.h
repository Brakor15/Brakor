#ifndef ia
#define ia

void ia_aleatoire(int* joueur2_x, int* joueur2_y, int modulo);

void ia_deplacement(int* joueur2_x, int* joueur2_y, int tab[][9], int taille_tableau);

void ia_cocher_case(int joueur1_x, int joueur1_y, int game_over_joueur1, int tab[][9], int taille_tableau);


#endif
