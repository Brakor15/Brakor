#ifndef HISTOIRE_H
#define HISTOIRE_H

void verification_sauvegarde(int* save);

void gagner_chapite(int *save);

int chapitre1(int succes_tab[], int* save);

int chapitre2(int succes_tab[], int* save);

int lancer_histoire(int succes_tab[]);

#endif
