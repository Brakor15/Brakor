/* Victorien Blanchard et Yann Pascoet */
#ifndef HISTOIRE_H
#define HISTOIRE_H

void verification_sauvegarde(int* save);

void gagner_chapite(int *save);

void chapitre1(int succes_tab[], int* save);

void lancer_histoire(int succes_tab[]);

#endif
