#include<stdlib.h>
#include<stdio.h>
#include"deroulement.h"

#define LONGUEUR_FENETRE 800
#define LARGEUR_FENETRE 800
#define JOUEUR_PAS_ENCORE_PLACE -1

/*Verification du nb de cases libre pour un joueur donné. Le joueur doit être donné en coordonnées int (x,y)*/

int dep_nb_case_possibles(int tab[][9], int taille_tableau, int pos_x, int pos_y){
  int nb_cases_disponibles = 0;

  printf("Verification du nombre de cases restantes pour le joueur actuel : ");
  if ((pos_x + 1 < taille_tableau) && (tab[pos_x + 1][pos_y] == 0))
    nb_cases_disponibles++;
  if ((pos_x - 1 >= 0) && (tab[pos_x - 1][pos_y] == 0))
    nb_cases_disponibles++;
  if ((pos_y + 1 < taille_tableau) && (tab[pos_x][pos_y + 1] == 0))
    nb_cases_disponibles++;
  if ((pos_y - 1 >= 0) && (tab[pos_x][pos_y - 1] == 0))
    nb_cases_disponibles++;

  if ((pos_x - 1 >= 0) && (pos_y - 1 >= 0) && (tab[pos_x-1][pos_y-1] == 0)) /*Haut à gauche*/
    nb_cases_disponibles++;
  if ((pos_x + 1 < taille_tableau) && (pos_y + 1 < taille_tableau) && (tab[pos_x+1][pos_y+1] == 0)) /*Bas à droite*/
    nb_cases_disponibles++;
  if ((pos_x - 1 >= 0) && (pos_y + 1 < taille_tableau) && (tab[pos_x-1][pos_y+1] == 0)) /*Bas à gauche */
    nb_cases_disponibles++;
  if ((pos_x + 1 < taille_tableau) && (pos_y - 1 >= 0) && (tab[pos_x+1][pos_y-1] == 0)) /*Haut à droite*/
    nb_cases_disponibles++;
  printf("Cases disponibles = %d\n", nb_cases_disponibles);

  return nb_cases_disponibles;
}

/* verification_case est une fonction qui verifie si une case précise du tableau est utilisée ou non
 * Pré-conditon : un tableau d'entiers à double dimension de taille 9x9, les positions de la case à verifier, en entiers, et en X et Y
 * Post-condition : Renvoie 1 si la case est utilisée, 0 si elle est libre
 */

int verification_case(int tab[][9], int position_x, int position_y){
  if (tab[position_x][position_y] != 0)
    return 1;
  return 0;
}

/*Calcul des coordonnées de la case cliquée, et stockage dans deux variables clic_x et clic_y*/

int case_cliquee(int taille_case, int mouse_pos_x, int mouse_pos_y, int* clic_x, int* clic_y){
  if (mouse_pos_x>LARGEUR_FENETRE||mouse_pos_y>LONGUEUR_FENETRE)
    return;
  *clic_x = mouse_pos_x/taille_case;
  *clic_y = mouse_pos_y/taille_case;
  printf("Calcul de la case cliquée\n");
  return 0;
}

/* deplacement_joueur est une fonction qui permet de deplacer un joueur vers une case voulue, rentrée en coordonnées (x,y) sur le plateau
 * Pré-conditions : donner le tableau 9x9, la position actuelle du joueur et la position vers laquelle on veut le déplacer
 * Post-condition : le joueur est déplacé vers une case voulue, et la case sur laquelle le joueur était est remplacé par un "0"
 */
void deplacement_joueur(int tab[][9], int* pos_x, int* pos_y, int pos_xx, int pos_yy){
  tab[pos_xx][pos_yy] = tab[*pos_x][*pos_y];
  tab[*pos_x][*pos_y] = 0;
  *pos_x = pos_xx;
  *pos_y = pos_yy;
}

int deplacement_verification(int tab[][9], int pos_x, int pos_y, int* pos_xx, int* pos_yy){
  if ((pos_x - *pos_xx) <= 1 && (pos_x - *pos_xx) >= -1 && (pos_y - *pos_yy) <= 1 && (pos_y - *pos_yy) >= -1)
    return 0;
  return 1;
}
