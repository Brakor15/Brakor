/* Victorien Blanchard et Yann Pascoet */
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<graph.h>
#include"achievements.h"
#include"affichage.h"

#define LARGEUR_FENETRE 800

int verification_achivement_deja_unlocked(int achivement_unlocked, int tableau_achivement[]){
  int i=0;
  FILE* achiv_file;
  achiv_file = fopen("achievements.txt", "r");
  if (achiv_file == NULL)
    printf("Failed to open file (aim : check), or file doesn't exist yet, please press the reset achievements bouton\n");
  else{
    fscanf(achiv_file, "%d %d", &tableau_achivement[0], &tableau_achivement[1]);
    printf("Verification succès %d\n", achivement_unlocked);
  }
  fclose(achiv_file);
  if (tableau_achivement[achivement_unlocked-1] == 1){ /* Premier succès, mais dans le fichier c'est le premier élément, et donc l'élément 0 du tableau*/
    printf("Succès %d deja debloque\n", achivement_unlocked);
    return 0;
  }
  else
    printf("Achivement %d n'a pas déjà été réalisé\n", achivement_unlocked);
  return 1;

}

void g_gagner_achiv(int numero_achiv, int achivement_unlocked[]){
  achivement_unlocked[numero_achiv-1] = 1; /* -1 car c'est le premier succès, mais le premier élément dans le fichier dans lequel on va écrire à l'aide du tableau */
  FILE* achiv_file;
  achiv_file = fopen("achievements.txt", "w");
  if (achiv_file == NULL)
    printf("Failed to open file (aim : display)\n");
  else{
    printf("Ecriture dans le fichier de succes, %d\n", achivement_unlocked[0]);
    fprintf(achiv_file, "%d %d", achivement_unlocked[0], achivement_unlocked[1]);
    fclose(achiv_file);
    afficher_succes(numero_achiv);
  }
}

void afficher_succes(int numero_achiv){
  int succes1 = ChargerSprite("images/achivements/1.png"), succes2 = ChargerSprite("images/achivements/2.png"), i;
  if (numero_achiv == 1){
    for(i=0; i<150; i++){
      AfficherSprite(succes1, LARGEUR_FENETRE-i*2, 100);
      usleep(6000);
    }
  }
  if (numero_achiv == 2){
    for(i=0; i<150; i++){
      AfficherSprite(succes1, LARGEUR_FENETRE-i*2, 100);
      usleep(6000);
    }
  }
  LibererSprite(succes2);
  LibererSprite(succes1);
}

void debloquer_succes(int achivement_unlocked, int tableau_achivement[]){
  if(verification_achivement_deja_unlocked(achivement_unlocked, tableau_achivement) == 1)
    g_gagner_achiv(achivement_unlocked, tableau_achivement);

}
