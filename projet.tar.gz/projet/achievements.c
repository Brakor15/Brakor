#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<graph.h>
#include"achievements.h"
#include"affichage.h"

#define LARGEUR_FENETRE 800


/* Compare un tableau dans lequel sont stockés les valeurs des succès avec le fichier de succès, remplis un tableau de succès en fonction du contenu du fichier
 * Pré-condition : l'entier correspondant au numéro du succès à vérifier, le tableau dans lequel seront stockés la valeur de chaque succès
 * Post-condition : renvoie 0 si le succès passé en argument a déjà été débloqué, 1 sinon
 */

int verification_achivement_deja_unlocked(int achivement_unlocked, int tableau_achivement[]){
  int i=0;
  FILE* achiv_file;
  achiv_file = fopen("achievements.txt", "r");
  if (achiv_file == NULL)
    printf("Failed to open file (aim : check), or file doesn't exist yet, please press the reset achievements bouton\n");
  else{
    fscanf(achiv_file, "%d %d", &tableau_achivement[0], &tableau_achivement[1]);
    printf("Verification succès %d\n", achivement_unlocked);
  }
  fclose(achiv_file);
  if (tableau_achivement[achivement_unlocked-1] == 1){ /* Premier succès, mais dans le fichier c'est le premier élément, et donc l'élément 0 du tableau*/
    printf("Succès %d deja debloque\n", achivement_unlocked);
    return 0;
  }
  else
    printf("Achivement %d n'a pas déjà été réalisé\n", achivement_unlocked);
  return 1;

}

/* Change le contenu du tableau de succès et écrit le contenu de celui ci dans le fichier de succès
 * Pré-condition : l'entier correspondant au numéro du succès à vérifier, le tableau dans lequel seront stockés la valeur de chaque succès
 * Post-condition : le fichier de succès est édité et est remplacé par les valeurs qui sont dans le tableau de succès, séparés par un espace
 */

void g_gagner_achiv(int numero_achiv, int achivement_unlocked[]){
  achivement_unlocked[numero_achiv-1] = 1; /* -1 car c'est le premier succès, mais le premier élément dans le fichier dans lequel on va écrire à l'aide du tableau */
  FILE* achiv_file;
  achiv_file = fopen("achievements.txt", "w");
  if (achiv_file == NULL)
    printf("Failed to open file (aim : display)\n");
  else{
    printf("Ecriture dans le fichier de succes, %d\n", achivement_unlocked[0]);
    fprintf(achiv_file, "%d %d", achivement_unlocked[0], achivement_unlocked[1]);
    fclose(achiv_file);
    afficher_succes(numero_achiv);
  }
}
/* Fait apparaitre un succès obtenu à l'écran avec une animation
 * Pré-condition : l'entier correspondant au numéro du succès à afficher
 * Post-condition : affiche à l'écran le succès à afficher avec une animation
 */
void afficher_succes(int numero_achiv){
  int succes1 = ChargerSprite("images/achivements/1.png"), succes2 = ChargerSprite("images/achivements/2.png"), i;
  if (numero_achiv == 1){
    for(i=0; i<150; i++){
      AfficherSprite(succes1, LARGEUR_FENETRE-i*2, 100);
      usleep(6000);
    }
  }
  if (numero_achiv == 2){
    for(i=0; i<150; i++){
      AfficherSprite(succes2, LARGEUR_FENETRE-i*2, 100);
      usleep(6000);
    }
  }
  LibererSprite(succes2);
  LibererSprite(succes1);
}
/* Fait gagner le succès voulu si celui ci n'a pas déjà été obtenu
 * Pré-condition : l'entier correspondant au numéro du succès à vérifier, le tableau dans lequel seront stockés la valeur de chaque succès
 * Post-condition : affiche le succès à voulu si celui ci n'a pas déjà été obtenu
 */
void debloquer_succes(int achivement_unlocked, int tableau_achivement[]){
  if(verification_achivement_deja_unlocked(achivement_unlocked, tableau_achivement) == 1)
    g_gagner_achiv(achivement_unlocked, tableau_achivement);

}
