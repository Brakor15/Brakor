#include<stdlib.h>
#include<stdio.h>
#include<graph.h>
#include<math.h>
#include"affichage.h"
#include"achievements.h"

#define LARGEUR_FENETRE 800
#define LONGUEUR_FENETRE 800
#define PLACEMENT 0
#define PHASE_DEP_JOUEUR 1
#define PHASE_COCHER_CASE 2

/* Décharge les sprites des murs
 * Pré-condition : l'entier représentant le sprite de chaque mur
 * Post-condition : décharge les sprites des murs de la mémoire
 */
void decharger_tous_sprites(int sprite_mur, int sp_bord_gauche, int sp_bord_droit,int sp_bord_haut,int sp_bord_bas){
  printf("Dechargement sprite : mur\n");
  LibererSprite(sprite_mur);
  printf("Dechargement sprite : bord_gauche\n");
  LibererSprite(sp_bord_gauche);
  printf("Dechargement sprite : bord_bas\n");
  LibererSprite(sp_bord_bas);
  printf("Dechargement sprite : bord_haut\n");
  LibererSprite(sp_bord_haut);
  printf("Dechargement sprite : bord_droit\n");
  LibererSprite(sp_bord_droit);
}


/* initialisation_jeu est une fonction qui remplis toutes les cases du tableau par un "0", et calcule et renvoie la taille de chaque case qui sera affichée à l'écran
 * Pré-condition : tableau d'entiers à double dimension de taille 9x9, la variable int taille_case ainsi que la taille_tableau
 * Post-condition : remplie le tableau de 0, et renvoie la taille des cases qui seront affichées
 */

void initialisation_jeu(int tab[][9], int* taille_case, int taille_tableau, int* sp_mur_normal,int* sp_bord_gauche,int* sp_bord_droit,int* sp_bord_haut, int* sp_bord_bas){
  int i, z;
  for(i=0; i<9; i++){
    for(z=0; z<9; z++){
      tab[z][i] = 0;
    }
  }
  *taille_case = (int)arrondi(((double)LARGEUR_FENETRE/(double)taille_tableau), 0);
  if (taille_tableau == 3){
    *sp_mur_normal = ChargerSprite("images/murs/3x3/mur3x3.png");
    *sp_bord_gauche = ChargerSprite("images/murs/3x3/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/3x3/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/3x3/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/3x3/mur_bas.png");
  }
  if (taille_tableau == 4){
    *sp_mur_normal = ChargerSprite("images/murs/4x4/mur4x4.png");
    *sp_bord_gauche = ChargerSprite("images/murs/4x4/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/4x4/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/4x4/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/4x4/mur_bas.png");
  }
  if (taille_tableau == 5){
    *sp_mur_normal = ChargerSprite("images/murs/5x5/mur5x5.png");
    *sp_bord_gauche = ChargerSprite("images/murs/5x5/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/5x5/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/5x5/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/5x5/mur_bas.png");
  }
  if (taille_tableau == 6){
    *sp_mur_normal = ChargerSprite("images/murs/6x6/mur6x6.png");
    *sp_bord_gauche = ChargerSprite("images/murs/6x6/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/6x6/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/6x6/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/6x6/mur_bas.png");
  }
  if (taille_tableau == 7){
    *sp_mur_normal = ChargerSprite("images/murs/7x7/mur7x7.png");
    *sp_bord_gauche = ChargerSprite("images/murs/7x7/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/7x7/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/7x7/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/7x7/mur_bas.png");
  }
  if (taille_tableau == 8){
    *sp_mur_normal = ChargerSprite("images/murs/8x8/mur8x8.png");
    *sp_bord_gauche = ChargerSprite("images/murs/8x8/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/8x8/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/8x8/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/8x8/mur_bas.png");
  }
  if (taille_tableau == 9){
    *sp_mur_normal = ChargerSprite("images/murs/9x9/mur9x9.png");
    *sp_bord_gauche = ChargerSprite("images/murs/9x9/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/9x9/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/9x9/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/9x9/mur_bas.png");
  }
}

/*Permet de calculer l'arondi d'un float, utilisé dans la fonction initialisation_jeu
 * Pré-condition : la valeur et le nombre de chiffres après la virgule sous forme d'entiers
 * Post-condition : Renvoie un double arrondit à l'unité voulue
 */

double arrondi(double value, int digits){
  return floor(value * pow(10, digits) + 0.5) / pow(10, digits);
}

/* Affiche graphiquement l'état actuel du plateau de jeu après calcul à l'aide des valeurs du tableau
 * Pré-condition : le tableau à double dimension du plateau de jeu, la taille d'une case, la taille du tableau choisit par l'utilisateur
 la phase de jeu actuelle, l'entier représentant les murs, donné par la fonction ChargerSprite()
 * Post-condition : Affiche à l'écran l'état actuel du jeu
 */

void g_affichage_plateau(int const tab[][9], int taille_case, int taille_tableau, int phase_de_jeu, int sprite_mur, int sp_bord_gauche, int sp_bord_droit,int sp_bord_haut,int sp_bord_bas){
  ChoisirEcran(1); /* Pour eviter les problemes d'affichage, on charge tout sur un écran virtuel, puis on affichera sur l'écran 0 */
  ChargerImage("images/fond.png",0,0,0,0,800,800);
  int i, z;
  int joueur1 = ChargerSprite("images/joueur1_perso.png"), joueur2 = ChargerSprite("images/joueur2_perso.png");


  for (i = 0; i<taille_tableau; i++){ /*Afin d'éviter certains problèmes d'affichage, on affiche les lignes sépremment*/
    if (i != 0){
      ChoisirCouleurDessin(CouleurParComposante(255,255,255));
      DessinerSegment(i*taille_case, 0, i*taille_case, LARGEUR_FENETRE);
    }

    for(z = 0; z<taille_tableau; z++){
      if (z != 0){
      	ChoisirCouleurDessin(CouleurParComposante(255,255,255));
      	DessinerSegment(0, z*taille_case, LONGUEUR_FENETRE, z*taille_case);
      }
    }
  }
  for(i=0; i<taille_tableau; i++){

    for(z=0; z<taille_tableau; z++){

      if (tab[i][z] == 1){ /*Ici on va afficher les bordures des murs en fonction des murs adjascents*/
      	AfficherSprite(sprite_mur, i*taille_case+5, z*taille_case+5);
      	if (i+1 < taille_tableau && tab[i+1][z] != 1)
      	  AfficherSprite(sp_bord_droit, i*taille_case+taille_case-(taille_case/20), z*taille_case);
      	if (i-1 < taille_tableau && tab[i-1][z] != 1)
      	  AfficherSprite(sp_bord_gauche, i*taille_case-(taille_case/20), z*taille_case);
      	if (z+1 < taille_tableau && tab[i][z+1] != 1)
      	  AfficherSprite(sp_bord_bas, i*taille_case, z*taille_case+taille_case-(taille_case/20));
      	if (z-1 < taille_tableau && tab[i][z-1] != 1)
      	  AfficherSprite(sp_bord_haut, i*taille_case, z*taille_case-(taille_case/20));
      }
      else if (tab[i][z] == 4){
      	AfficherSprite(joueur1, i*taille_case+(taille_case-80)/2, z*taille_case+(taille_case-83)/2); /* 80, 83, sont les dimensions des sprites des personnages*/

      }
      else if (tab[i][z] == 8){
      	AfficherSprite(joueur2, i*taille_case+(taille_case-80)/2, z*taille_case+(taille_case-83)/2);

      }

    }

  }
  LibererSprite(joueur1);
  LibererSprite(joueur2);
  ChargerImage("images/fond_bordures.png",0,0,0,0,800,800);
  /* On affiche en bas de l'écran l'action en cours*/
  /* Mais avant on crée un carré noir dans lequel vont se placer les images */
  ChoisirCouleurDessin(CouleurParComposante(0,0,0));
  RemplirRectangle(LARGEUR_FENETRE/2-200, LONGUEUR_FENETRE-30, 400, 30);
  ChoisirCouleurDessin(CouleurParComposante(255,255,255));
  if(phase_de_jeu == PHASE_DEP_JOUEUR)
    ChargerImage("images/textes/DEP.png", LARGEUR_FENETRE/2-115, LONGUEUR_FENETRE-30, 0, 0, 500, 200);
  else if (phase_de_jeu == PLACEMENT)
    ChargerImage("images/textes/PLACEMENT.png", LARGEUR_FENETRE/2-150, LONGUEUR_FENETRE-30, 0, 0, 500, 200);
  else if (phase_de_jeu == PHASE_COCHER_CASE)
    ChargerImage("images/textes/COCHER.png", LARGEUR_FENETRE/2-150, LONGUEUR_FENETRE-25, 0, 0, 500, 200);

  CopierZone(1, 0, 0, 0, 800, 800, 0, 0);

  ChoisirEcran(0);
}

/* Affiche graphiquement les succès débloqués ou non débloqués dans un nouvel écran
 * Pré-condition : le tableau des succès
 * Post-condition : Affiche à l'écran l'état actuel des succès dans une nouvelle fenetre
 */

 void g_affichage_achivment(int tab_succes_debloques[]){

  FILE* achiv_file;
  ChargerImageFond("images/fond_achiv3.png");
  achiv_file = fopen("achievements.txt", "r");
  if (achiv_file != NULL){
    fscanf(achiv_file, "%d %d", &tab_succes_debloques[0], &tab_succes_debloques[1]);
    printf("%d %d\n", tab_succes_debloques[0], tab_succes_debloques[1]);
  }
  else
    printf("Problème lors de l'ouverture du fichier de succès");
  if (tab_succes_debloques[0] == 1){
    ChargerImage("images/achivements/1.png", LARGEUR_FENETRE/4+50, LONGUEUR_FENETRE/4+50, 0, 0, 300, 100);
    printf("Affichage succès");
  }
  else{
    ChargerImage("images/achivements/1_not_unlocked.png", LARGEUR_FENETRE/4+50, LONGUEUR_FENETRE/4+50, 0, 0, 300, 100);
  }
  if (tab_succes_debloques[1] == 1){
    ChargerImage("images/achivements/2.png", LARGEUR_FENETRE/4+50, LONGUEUR_FENETRE/2+50, 0, 0, 300, 100);
    printf("Affichage succès");
  }
  else{
    ChargerImage("images/achivements/2_not_unlocked.png", LARGEUR_FENETRE/4+50, LONGUEUR_FENETRE/2+50, 0, 0, 300, 100);
  }

  fclose(achiv_file);
}
