#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include "affichage.h"
#include "achievements.h"
#include "ia.h"
#include "partie.h"

#define MAX 9
#define LARGEUR_FENETRE 800
#define LONGUEUR_FENETRE 800

#define PLACEMENT 0
#define PHASE_DEP_JOUEUR 1
#define PHASE_COCHER_CASE 2




void partie(int taille_tableau, int nombre_joueurs, int nombre_de_joueurs_ia){

	int test, tab[MAX][MAX], taille_case, clic_x, clic_y, joueur_actuel = 0, i;
	int phase_de_jeu = PLACEMENT, achiv_unlocked[3] = {0};
	int sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas, sprite_fond_achiv = ChargerSprite("fond_achiv3.png"), sprite_achiv_1 = ChargerSprite("images/achiv_1.png"); /*Sprites */


	Joueur joueur[nombre_joueurs];
	for( i = 0; i < (nombre_joueurs - nombre_de_joueurs_ia); i++){
			joueur[i].ia_ou_joueur = 0;
	}
	for (i = (nombre_joueurs - nombre_de_joueurs_ia); i < nombre_joueurs; i++){
		joueur[i].ia_ou_joueur = 1;
		printf("lol\n");
	}
	for (i = 0; i < nombre_joueurs; i++){
		if (joueur[i].ia_ou_joueur == 0)
			printf("Joueur %d n'est pas ia\n", i);
		else
			printf("Joueur %d EST ia\n", i);
	}
	/*On initialise le tableau en fonction de la taille_tableau choisit par l'utilisateur lors du menu */
	initialisation_jeu(tab, &taille_case, taille_tableau, &sp_mur_normal, &sp_bord_gauche, &sp_bord_droit, &sp_bord_haut, &sp_bord_bas);
	print_board(tab, taille_tableau); /*Affichage en console pour debeugage*/
	g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu, sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */
	printf("nb de joueurs = %d\n", nombre_joueurs);

	while(1){

			if(joueur_actuel == nombre_joueurs){
				joueur_actuel = 0;
				printf("Joueur actuel remis à 0\n");
			}
			if(joueur[joueur_actuel].ia_ou_joueur == 1){
				printf("Joueur ia Numéro %d joue... phase de jeu = %d\n", joueur_actuel+1, phase_de_jeu);
				switch(phase_de_jeu){

					case PLACEMENT:
						printf("Placement du joueur 2\n");
						usleep(500000);
						ia_aleatoire(&joueur[joueur_actuel].position_x, &joueur[joueur_actuel].position_y, taille_tableau);
						while(verification_case(tab, joueur[joueur_actuel].position_x, joueur[joueur_actuel].position_y) != 0){
							ia_aleatoire(&joueur[joueur_actuel].position_x, &joueur[joueur_actuel].position_y, taille_tableau);
						}
						tab[joueur[joueur_actuel].position_x][joueur[joueur_actuel].position_y] = 8;
						printf("Joueur actuel = %d\n", joueur_actuel);
						joueur_actuel++;
						if (joueur_actuel == nombre_joueurs){
							phase_de_jeu = PHASE_DEP_JOUEUR;
						}
						break;

					case PHASE_DEP_JOUEUR:
						ia_deplacement(&joueur[joueur_actuel].position_x, &joueur[joueur_actuel].position_y, tab, taille_tableau);
						phase_de_jeu = PHASE_COCHER_CASE;
						usleep(500000);
						break;

					case PHASE_COCHER_CASE:
						joueur[0].nombre_de_cases_libres = dep_nb_case_possibles(tab, taille_tableau, joueur[0].position_x, joueur[0].position_y);
						ia_cocher_case(joueur[0].position_x, joueur[0].position_y, joueur[0].nombre_de_cases_libres, tab, taille_tableau);
						usleep(500000);
						joueur_actuel++;
						phase_de_jeu = PHASE_DEP_JOUEUR;
						break;
					default: break;
				}
				print_board(tab, taille_tableau);/*Affichage console pour débeugage*/
				g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu,
					sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */
				if(joueur_actuel == nombre_joueurs){
					joueur_actuel = 0;
					printf("Joueur actuel remis à 0\n");
					putchar('\n');
				}
				printf("PHASE DE JEU %d\n", phase_de_jeu);
				printf("ia OUI NON %d \n", joueur[joueur_actuel].ia_ou_joueur);


			}

			if (SourisCliquee() && joueur[joueur_actuel].ia_ou_joueur == 0){
				/*if(joueur_actuel == nombre_joueurs)
					joueur_actuel = 0;*/
				printf("Début du tour! Joueur actuel = %d\n", joueur_actuel);
				print_board(tab, taille_tableau);/*Affichage console pour débeugage*/
				clic_x = _X;
				clic_y = _Y;
				case_cliquee(taille_case, _X, _Y, &clic_x, &clic_y); /*On stocke la valeurs des cases cliquees en X et en Y dans les variables clic_x et clic_y*/

				test = verification_case(tab, clic_x, clic_y); /*On verifie si la case n'est pas deja à "1" */


				if (test == 0){
					if(phase_de_jeu == PLACEMENT || joueur[joueur_actuel].nombre_de_cases_libres != 0){
						switch(phase_de_jeu){
							case PLACEMENT:
								printf("Placement du joueur %d\n", joueur_actuel);
								if (joueur_actuel == 0){
									tab[clic_x][clic_y] = 4;
								}
								else{
									tab[clic_x][clic_y] = 8;
								}
								joueur[joueur_actuel].position_x = clic_x;
								joueur[joueur_actuel].position_y = clic_y;
								joueur_actuel++;
								if (joueur_actuel == nombre_joueurs)
									phase_de_jeu = PHASE_DEP_JOUEUR;
								break;


							/*Partie où les joueurs déplacent leur pions */
							case PHASE_DEP_JOUEUR:
								printf("DEPLACEMENT\n");
								printf("Joueur actuel = %d, position_x = %d\n", joueur_actuel, joueur[joueur_actuel].position_x);
								if (deplacement_verification(tab, joueur[joueur_actuel].position_x, joueur[joueur_actuel].position_y, &clic_x, &clic_y) == 0){
									deplacement_joueur(tab, &joueur[joueur_actuel].position_x, &joueur[joueur_actuel].position_y, clic_x, clic_y);
									phase_de_jeu = PHASE_COCHER_CASE;
								}
								break;

							/*Partie où les joueurs cochent des cases */
							case PHASE_COCHER_CASE:
								tab[clic_x][clic_y] = 1;
								phase_de_jeu = PHASE_DEP_JOUEUR;
								if (joueur_actuel == nombre_joueurs){
									joueur_actuel++;
									break;
								}
								joueur_actuel++;
								break;


							default:
								break;
							}

							if(joueur_actuel == nombre_joueurs){
								joueur_actuel = 0;
								printf("Joueur actuel remis à 0\n");
							}
						}
					} /* if (test == 0) */
					print_board(tab, taille_tableau);/*Affichage console pour débeugage*/

					g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu,
						sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */

				if(phase_de_jeu != PLACEMENT){
					joueur[joueur_actuel].nombre_de_cases_libres = dep_nb_case_possibles(tab, taille_tableau, joueur[joueur_actuel].position_x, joueur[joueur_actuel].position_y);
					if (joueur[joueur_actuel].nombre_de_cases_libres == 0){
						printf("GAME OVER JOUEUR JOUEUR %d, nombre_de_cases_libres = %d\n", joueur_actuel+1, joueur[joueur_actuel].nombre_de_cases_libres);
						decharger_tous_sprites(sp_mur_normal, sp_bord_bas, sp_bord_haut, sp_bord_gauche, sp_bord_droit);
						return;
					}
				}


		}/*Fin des de tous les If */



		if (ToucheEnAttente()){
			if(Touche() == XK_Escape){ /*Si on appuis sur Echap pendant le prog, ca quitte*/
				decharger_tous_sprites(sp_mur_normal, sp_bord_bas, sp_bord_haut, sp_bord_gauche, sp_bord_droit);
				FermerGraphique();
				return;
      }
		else{
			printf("Achivement_ouvert\n");
				g_affichage_achivment(sprite_fond_achiv, achiv_unlocked);
				while(1){
					if(Touche()){
						ChargerImage("images/fond.png",0,0,0,0,LARGEUR_FENETRE,LONGUEUR_FENETRE);
						g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu, sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */
							break;
						}
				}
				printf("Achivement_fermé\n");

			}
		}
}

	decharger_tous_sprites(sp_mur_normal, sp_bord_bas, sp_bord_haut, sp_bord_gauche, sp_bord_droit);
	return;
}
