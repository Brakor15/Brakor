#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include <math.h>
#include "affichage.h"
#include "achievements.h"
#include "ia.h"
#include "partie.h"

#define MAX 9
#define LARGEUR_FENETRE 800
#define LONGUEUR_FENETRE 800

#define PLACEMENT 0
#define PHASE_DEP_JOUEUR 1
#define PHASE_COCHER_CASE 2




void partie(int taille_tableau, int nombre_joueurs, int nombre_de_joueurs_ia, int tab_succes_debloques[]){

	int test, tab[MAX][MAX], taille_case, clic_x, clic_y, joueur_actuel = 0, i;
	int phase_de_jeu = PLACEMENT;
	int sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas;

	Joueur joueur[nombre_joueurs];

	joueur[0].numero = 4;
	printf("Numero de joueur humain = %d\n",joueur[0].numero);
	for (i = 0; i < (int)fabs(nombre_de_joueurs_ia - nombre_joueurs); i++){
		joueur[i].ia_ou_joueur = 0;
	}
	for (i; i < nombre_joueurs; i++){
		joueur[i].ia_ou_joueur = 1;
		printf("Numero de joueur IA = %d\n",joueur[i].numero);
	}
	for (i = 0; i < nombre_joueurs; i++){
		if (i != 0){
			joueur[i].numero = 8;
		}
		if (joueur[i].ia_ou_joueur == 0)
		printf("Joueur %d n'est pas ia\n", i);
		else
		printf("Joueur %d EST ia\n", i);
	}
	/*On initialise le tableau en fonction de la taille_tableau choisit par l'utilisateur lors du menu */
	initialisation_jeu(tab, &taille_case, taille_tableau, &sp_mur_normal, &sp_bord_gauche, &sp_bord_droit, &sp_bord_haut, &sp_bord_bas);
	print_board(tab, taille_tableau); /*Affichage en console pour debeugage*/
	g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu, sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */
	printf("nb de joueurs = %d\n", nombre_joueurs);

	while(1){

		if (SourisCliquee() || joueur[joueur_actuel].ia_ou_joueur == 1){
			printf("Joueur %d joue\n", joueur_actuel);
			if (joueur[joueur_actuel].ia_ou_joueur == 0){
				SourisPosition();
				clic_x = _X;
				clic_y = _Y;
			}

			if(phase_de_jeu == PLACEMENT || joueur[joueur_actuel].nombre_de_cases_libres != 0){
				switch(phase_de_jeu){
					case PLACEMENT:
					if (joueur[joueur_actuel].ia_ou_joueur == 0 && case_cliquee(taille_case, _X, _Y, &clic_x, &clic_y) == 0){
						joueur[joueur_actuel].position_x = clic_x;
						joueur[joueur_actuel].position_y = clic_y;
						tab[clic_x][clic_y] = joueur[joueur_actuel].numero;
						joueur_actuel++;
					}
					else if (joueur[joueur_actuel].ia_ou_joueur == 1){
						printf("Placement IA n° %d\n", joueur_actuel+1);
						usleep(500000);
						ia_aleatoire(&joueur[joueur_actuel].position_x, &joueur[joueur_actuel].position_y, taille_tableau);
						while(verification_case(tab, joueur[joueur_actuel].position_x, joueur[joueur_actuel].position_y) != 0){
							ia_aleatoire(&joueur[joueur_actuel].position_x, &joueur[joueur_actuel].position_y, taille_tableau);
						}
						tab[joueur[joueur_actuel].position_x][joueur[joueur_actuel].position_y] = joueur[joueur_actuel].numero;
						joueur_actuel++;
					}
					if (joueur_actuel == nombre_joueurs){
						phase_de_jeu = PHASE_DEP_JOUEUR;
						printf("LE JEU COMMENCE ! \n");
					}
					break;


					/*Partie où les joueurs déplacent leur pions */
					case PHASE_DEP_JOUEUR:
					printf("Deplacement joueur %d\n", joueur_actuel);
					if (joueur[joueur_actuel].ia_ou_joueur == 0 && case_cliquee(taille_case, _X, _Y, &clic_x, &clic_y) == 0 && tab[clic_x][clic_y] == 0){
						printf("CASE CLIQUEE X = %d CASE CLIQUEE Y = %d\n", clic_x, clic_y);
						if (deplacement_verification(tab, joueur[joueur_actuel].position_x, joueur[joueur_actuel].position_y, &clic_x, &clic_y) == 0){
							deplacement_joueur(tab, &joueur[joueur_actuel].position_x, &joueur[joueur_actuel].position_y, clic_x, clic_y);
							phase_de_jeu = PHASE_COCHER_CASE;
							printf("Changement de phase\n");
						}
					}
					else if (joueur[joueur_actuel].ia_ou_joueur == 1){
						ia_deplacement(&joueur[joueur_actuel].position_x, &joueur[joueur_actuel].position_y, tab, taille_tableau);
						phase_de_jeu = PHASE_COCHER_CASE;
						usleep(500000);
					}
					break;

					/*Partie où les joueurs cochent des cases */
					case PHASE_COCHER_CASE:
					if (joueur[joueur_actuel].ia_ou_joueur == 0 && case_cliquee(taille_case, _X, _Y, &clic_x, &clic_y) == 0 && tab[clic_x][clic_y] == 0){
						tab[clic_x][clic_y] = 1;
						phase_de_jeu = PHASE_DEP_JOUEUR;
					}
					else if (joueur[joueur_actuel].ia_ou_joueur == 1){
						joueur[0].nombre_de_cases_libres = dep_nb_case_possibles(tab, taille_tableau, joueur[0].position_x, joueur[0].position_y);
						ia_cocher_case(joueur[0].position_x, joueur[0].position_y, joueur[0].nombre_de_cases_libres, tab, taille_tableau);
						usleep(500000);
						phase_de_jeu = PHASE_DEP_JOUEUR;
					}
					joueur_actuel++;
					break;

					default:
					break;
				}

				if(joueur_actuel == nombre_joueurs){
					joueur_actuel = 0;
					printf("Joueur actuel remis à 0\n");
				}
			}
			g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu,
				sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */

				if(phase_de_jeu != PLACEMENT){
					joueur[joueur_actuel].nombre_de_cases_libres = dep_nb_case_possibles(tab, taille_tableau, joueur[joueur_actuel].position_x, joueur[joueur_actuel].position_y);
					if (joueur[joueur_actuel].nombre_de_cases_libres == 0){
						printf("GAME OVER JOUEUR JOUEUR %d, nombre_de_cases_libres = %d\n", joueur_actuel, joueur[joueur_actuel].nombre_de_cases_libres);
						decharger_tous_sprites(sp_mur_normal, sp_bord_bas, sp_bord_haut, sp_bord_gauche, sp_bord_droit);
						return;
					}
					joueur[0].nombre_de_cases_libres = dep_nb_case_possibles(tab, taille_tableau, joueur[0].position_x, joueur[0].position_y);
					if(joueur[0].nombre_de_cases_libres == 0 && phase_de_jeu == PHASE_DEP_JOUEUR){
						debloquer_succes(1, tab_succes_debloques);
					}
				}

				print_board(tab, taille_tableau);/*Affichage console pour débeugage*/

			}/*If souriscliquee...*/



			if (ToucheEnAttente()){
				if(Touche() == XK_Escape){ /*Si on appuis sur Echap pendant le prog, ca quitte*/
					decharger_tous_sprites(sp_mur_normal, sp_bord_bas, sp_bord_haut, sp_bord_gauche, sp_bord_droit);
					FermerGraphique();
					return;
				}
				else{
					printf("Achivement_ouvert\n");
					g_affichage_achivment(tab_succes_debloques);
					while(1){
						if(Touche()){
							ChargerImage("images/fond.png",0,0,0,0,LARGEUR_FENETRE,LONGUEUR_FENETRE);
							g_affichage_plateau(tab, taille_case, taille_tableau, phase_de_jeu, sp_mur_normal, sp_bord_gauche, sp_bord_droit, sp_bord_haut, sp_bord_bas); /*On affiche le tableau en fonction de ce qu'il y a dans le tableau */
							break;
						}
					}
					printf("Achivement_fermé\n");

				}
			}
		}

		decharger_tous_sprites(sp_mur_normal, sp_bord_bas, sp_bord_haut, sp_bord_gauche, sp_bord_droit);
		return;
	}
