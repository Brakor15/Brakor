#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include "histoire.h"
#include "partie.h"

void verification_sauvegarde(int* save){
  FILE* fichier_sauvegarde;
  int creer_fichier = 0;
  fichier_sauvegarde = fopen("histoire/save", "r");
  if (fichier_sauvegarde == NULL){
    printf("Failed to open save file\n");
    fichier_sauvegarde = fopen("histoire/save", "w");
    fwrite(&creer_fichier, 4, 1, fichier_sauvegarde);
  }
  else{
    fread(save, 4, 1, fichier_sauvegarde);
    printf("Verification save \n");
  }
  fclose(fichier_sauvegarde);
}


void gagner_chapite(int *save){
  FILE* fichier_sauvegarde;
  fichier_sauvegarde = fopen("histoire/save", "w");
  if (fichier_sauvegarde == NULL){
    printf("Failed to open save file (aim : write)\n");
    return;
  }
  *save = 1;
  printf("save = %d, writting save into file", *save);
  fwrite(save, 4, 1, fichier_sauvegarde);
  fclose(fichier_sauvegarde);
}

void chapitre1(int succes_tab[], int* save){
  int i, fond = ChargerSprite("images/fond.png");
  int mineur = ChargerSprite("images/perso_1_histoire.png"), mineur2 = ChargerSprite("images/perso_1_2_histoire.png");
  int enemi = ChargerSprite("images/perso_2_histoire.png");
  for (i = 0; i < 4; i++){
    ChoisirEcran(1);
    AfficherSprite(fond, 0, 0);
    switch(i){
      case 0:
        AfficherSprite(mineur, 550, 500);
        AfficherSprite(mineur, 620, 500);
        AfficherSprite(mineur, 700, 500);
        ChargerImage("histoire/1_1.png", 0, 600, 0, 0, 800, 200);
        break;
      case 1:
        AfficherSprite(fond, 0, 0);
        AfficherSprite(enemi, 70, 500);
        ChargerImage("histoire/1_2.png", 0, 600, 0, 0, 800, 200);
        break;
      case 2:
        AfficherSprite(fond, 0, 0);
        AfficherSprite(mineur2, 650, 500);
        ChargerImage("histoire/1_3.png", 0, 600, 0, 0, 800, 200);
        break;
      case 3:
        AfficherSprite(mineur2, 650, 500);
        ChargerImage("histoire/1_4.png", 0, 600, 0, 0, 800, 200);
    }
    CopierZone(1, 0, 0, 0, 800, 800, 0, 0);
    while(!SourisCliquee());
  }
  LibererSprite(mineur);
  LibererSprite(mineur2);
  LibererSprite(fond);
  LibererSprite(enemi);
  ChoisirEcran(0);
  if (partie(8, 3, 2, succes_tab) != 1)
    gagner_chapite(save);
  else
    return;
}




void lancer_histoire(int succes_tab[]){
  int save = 0;
  verification_sauvegarde(&save);
  if (save == 0){
    chapitre1(succes_tab, &save);
    return;
  }
  else if(save > 0){
    printf("save>0\n");
    debloquer_succes(2, succes_tab);
    /*Lancer histoire 2*/
  }
}
