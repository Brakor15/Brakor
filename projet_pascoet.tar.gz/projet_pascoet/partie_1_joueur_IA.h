#ifndef PARTIE_1_JOUEUR_IA
#define PARTIE_1_JOUEUR_IA

void IA_aleatoire(int* joueur2_x, int* joueur2_y, int modulo);

void IA_deplacement(int* joueur2_x, int* joueur2_y, int tab[][9], int taille_tableau);

void IA_cocher_case(int joueur1_x, int joueur1_y, int game_over_joueur1, int tab[][9], int taille_tableau);


#endif
