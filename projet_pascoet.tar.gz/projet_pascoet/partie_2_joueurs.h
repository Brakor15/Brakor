#ifndef PARTIE_2_JOUEURS
#define PARTIE_2_JOUEURS


void partie_deux_joueurs(int taille_tableau);

#endif
