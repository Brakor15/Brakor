#include<stdlib.h>
#include<stdio.h>
#include"affichage.h"
#include"achievements.h"
#include<graph.h>
#include<math.h>


#define LARGEUR_FENETRE 800
#define LONGUEUR_FENETRE 800

#define PLACEMENT_JOUEUR_UN 14
#define PLACEMENT_JOUEUR_DEUX 18
#define PHASE_COCHER_CASE1 11
#define PHASE_DEP_JOUEUR1 1
#define PHASE_DEP_JOUEUR2 2
#define PHASE_COCHER_CASE2 22


/* initialisation_jeu est une fonction qui remplis toutes les cases du tableau par un "0", et calcule et renvoie la taille de chaque case qui sera affichée à l'écran
 * Pré-condition : tableau d'entiers à double dimension de taille 9x9, la variable int taille_case ainsi que la taille_tableau
 * Post-condition : remplie le tableau de 0, et renvoie la taille des cases qui seront affichées
 */

void initialisation_jeu(int tab[][9], int* taille_case, int taille_tableau, int* sp_mur_normal,int* sp_bord_gauche,int* sp_bord_droit,int* sp_bord_haut, int* sp_bord_bas){
  int i, z;
  for(i=0; i<9; i++){
    for(z=0; z<9; z++){
      tab[z][i] = 0;
    }
  }
  *taille_case = (int)arrondi(((double)LARGEUR_FENETRE/(double)taille_tableau), 0);
  if (taille_tableau == 3){
    *sp_mur_normal = ChargerSprite("images/murs/3x3/mur3x3.png");
    *sp_bord_gauche = ChargerSprite("images/murs/3x3/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/3x3/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/3x3/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/3x3/mur_bas.png");
  }
  if (taille_tableau == 4){
    *sp_mur_normal = ChargerSprite("images/murs/4x4/mur4x4.png");
    *sp_bord_gauche = ChargerSprite("images/murs/4x4/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/4x4/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/4x4/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/4x4/mur_bas.png");
  }
  if (taille_tableau == 5){
    *sp_mur_normal = ChargerSprite("images/murs/5x5/mur5x5.png");
    *sp_bord_gauche = ChargerSprite("images/murs/5x5/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/5x5/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/5x5/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/5x5/mur_bas.png");
  }
  if (taille_tableau == 6){
    *sp_mur_normal = ChargerSprite("images/murs/6x6/mur6x6.png");
    *sp_bord_gauche = ChargerSprite("images/murs/6x6/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/6x6/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/6x6/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/6x6/mur_bas.png");
  }
  if (taille_tableau == 7){
    *sp_mur_normal = ChargerSprite("images/murs/7x7/mur7x7.png");
    *sp_bord_gauche = ChargerSprite("images/murs/7x7/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/7x7/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/7x7/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/7x7/mur_bas.png");
  }
  if (taille_tableau == 8){
    *sp_mur_normal = ChargerSprite("images/murs/8x8/mur8x8.png");
    *sp_bord_gauche = ChargerSprite("images/murs/8x8/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/8x8/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/8x8/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/8x8/mur_bas.png");
  }
  if (taille_tableau == 9){
    *sp_mur_normal = ChargerSprite("images/murs/9x9/mur9x9.png");
    *sp_bord_gauche = ChargerSprite("images/murs/9x9/mur_gauche.png");
    *sp_bord_droit = ChargerSprite("images/murs/9x9/mur_droite.png");
    *sp_bord_haut = ChargerSprite("images/murs/9x9/mur_haut.png");
    *sp_bord_bas = ChargerSprite("images/murs/9x9/mur_bas.png");
  }
}

/*Permet de calculer l'arondi d'un float, utilisé dans la fonction initialisation_jeu
 *
 * Post-condition : Renvoie un double arrondit à l'unité voulue
 */

double arrondi(double value, int digits){
  return floor(value * pow(10, digits) + 0.5) / pow(10, digits);
}

/*Affichage graphique des elements après lecture dans le tableau : affiche un carre vide pour chaque 0, une croix pour chaque 1, un 4 pour le joueur 1, un 8 pour le joueur 2*/
/*Pour le moment, n'affiche que les carrés*/

void g_affichage_plateau(int const tab[][9], int taille_case, int taille_tableau, int phase_de_jeu, int sprite_mur, int sp_bord_gauche, int sp_bord_droit,int sp_bord_haut,int sp_bord_bas){
  ChoisirEcran(1); /* Pour eviter les problemes d'affichage */
  ChargerImage("images/fond.png",0,0,0,0,800,800);
  int pos_case_x, pos_case_y, pos_case_x2, pos_case_y2, i, z, joueur1 = ChargerSprite("images/joueur1_perso.png"), joueur2 = ChargerSprite("images/joueur2_perso.png");
  for (i = 0; i<taille_tableau; i++){
    if (i != 0){
      ChoisirCouleurDessin(CouleurParComposante(255,255,255));
      DessinerSegment(i*taille_case, 0, i*taille_case, LARGEUR_FENETRE);
    }

    for(z = 0; z<taille_tableau; z++){
      if (z != 0){
	ChoisirCouleurDessin(CouleurParComposante(255,255,255));
	DessinerSegment(0, z*taille_case, LONGUEUR_FENETRE, z*taille_case);
      }
    }
  }
  for(i=0; i<taille_tableau; i++){

    for(z=0; z<taille_tableau; z++){

      if (tab[i][z] == 1){
	AfficherSprite(sprite_mur, i*taille_case+5, z*taille_case+5);
	if (i+1 < taille_tableau && tab[i+1][z] != 1)
	  AfficherSprite(sp_bord_droit, i*taille_case+taille_case-(taille_case/20), z*taille_case);
	if (i-1 < taille_tableau && tab[i-1][z] != 1)
	  AfficherSprite(sp_bord_gauche, i*taille_case-(taille_case/20), z*taille_case);
	if (z+1 < taille_tableau && tab[i][z+1] != 1)
	  AfficherSprite(sp_bord_bas, i*taille_case, z*taille_case+taille_case-(taille_case/20));
	if (z-1 < taille_tableau && tab[i][z-1] != 1)
	  AfficherSprite(sp_bord_haut, i*taille_case, z*taille_case-(taille_case/20));
      }
      else if (tab[i][z] == 4){
	AfficherSprite(joueur1, i*taille_case+(taille_case-80)/2, z*taille_case+(taille_case-83)/2); /* 80, 83, sont les dimensions des sprites des personnages*/
	LibererSprite(joueur1);
      }
      else if (tab[i][z] == 8){
	AfficherSprite(joueur2, i*taille_case+(taille_case-80)/2, z*taille_case+(taille_case-83)/2);
	LibererSprite(joueur2);
      }

    }

  }

  ChargerImage("images/fond_bordures.png",0,0,0,0,800,800);
  ChoisirCouleurDessin(CouleurParComposante(0,0,0));
  RemplirRectangle(LARGEUR_FENETRE/2-260, LONGUEUR_FENETRE-30, 520, 30);
  ChoisirCouleurDessin(CouleurParComposante(255,255,255));
  /* On affiche en bas de l'écran l'action en cours*/

  if(phase_de_jeu == PHASE_DEP_JOUEUR1)
    ChargerImage("images/textes/J1DEP.png", LARGEUR_FENETRE/2-225, LONGUEUR_FENETRE-30, 0, 0, 500, 200);
  else if (phase_de_jeu == PHASE_DEP_JOUEUR2)
    ChargerImage("images/textes/J2DEP.png", LARGEUR_FENETRE/2-225, LONGUEUR_FENETRE-30, 0, 0, 500, 200);
  else if (phase_de_jeu == PHASE_COCHER_CASE1)
    ChargerImage("images/textes/J1COCHER.png", LARGEUR_FENETRE/2-250, LONGUEUR_FENETRE-25, 0, 0, 500, 200);
  else if (phase_de_jeu == PHASE_COCHER_CASE2)
    ChargerImage("images/textes/J2COCHER.png", LARGEUR_FENETRE/2-250, LONGUEUR_FENETRE-25, 0, 0, 500, 200);
  else if (phase_de_jeu == PLACEMENT_JOUEUR_UN)
    ChargerImage("images/textes/J1DEP.png", LARGEUR_FENETRE/2-225, LONGUEUR_FENETRE-30, 0, 0, 500, 200);
  else if(phase_de_jeu == PLACEMENT_JOUEUR_DEUX)
    ChargerImage("images/textes/J1DEP.png", LARGEUR_FENETRE/2-225, LONGUEUR_FENETRE-30, 0, 0, 500, 200);
  CopierZone(1, 0, 0, 0, 800, 800, 0, 0);
  ChoisirEcran(0);
}

/* A finir quand on a les ressources graphiques */
void g_affichage_achivment(int sprite_fond, int achiv_unlocked[]){

  FILE* achiv_file;
  ChargerImageFond("images/fond_achiv3.png");
  achiv_file = fopen("achivments.txt", "r");
  if (achiv_file != NULL){
    fscanf(achiv_file, "%d %d", &achiv_unlocked[0], &achiv_unlocked[1]);
    printf("%d %d\n", achiv_unlocked[0], achiv_unlocked[1]);
  }
  else
    printf("Problème lors de l'ouverture du fichier de succès");
  if (achiv_unlocked[0] == 1){
    ChargerImage("images/achivements/1.png", LARGEUR_FENETRE/4, LONGUEUR_FENETRE/4, 0, 0, 300, 100);
    printf("Affichage succès");
  }
  if (achiv_unlocked[1] == 1){
    ChargerImage("images/achivements/1.png", LARGEUR_FENETRE/4, LONGUEUR_FENETRE/2, 0, 0, 300, 100);
    printf("Affichage succès");
  }

  fclose(achiv_file);
}


void decharger_tous_sprites(int sprite_mur, int sp_bord_gauche, int sp_bord_droit,int sp_bord_haut,int sp_bord_bas){
  printf("Dechargement sprite : mur\n");
  LibererSprite(sprite_mur);
  printf("Dechargement sprite : bord_gauche\n");
  LibererSprite(sp_bord_gauche);
  printf("Dechargement sprite : bord_bas\n");
  LibererSprite(sp_bord_bas);
  printf("Dechargement sprite : bord_haut\n");
  LibererSprite(sp_bord_haut);
  printf("Dechargement sprite : bord_droit\n");
  LibererSprite(sp_bord_droit);
}
