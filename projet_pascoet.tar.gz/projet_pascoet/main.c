#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include "partie_2_joueurs.h"
#include "partie_1_joueur.h"

#define MAX 9
#define LARGEUR_FENETRE 800
#define LONGUEUR_FENETRE 800

/*Affichage console, sera retiré */
void print_board(int tab[][9], int taille_tableau){
  int i,z;

  for(i=0; i<taille_tableau; i++){
    for(z=0; z<taille_tableau; z++){
      if (tab[z][i] == 0)
	printf("0");
      else{
	printf("%d", tab[z][i]);
      }
    }
    putchar('\n');
  }
  putchar('\n');
}



int main(void){
	int taille_tableau = MAX, selection = 0;
	InitialiserGraphique();
  CreerFenetre(150,150,LARGEUR_FENETRE,LONGUEUR_FENETRE);

	while(1){
		menu(&taille_tableau, &selection);

		if (selection == 1)
      partie_un_joueur(taille_tableau);
    if (selection == 2)
			partie_deux_joueurs(taille_tableau);
		if (selection == 3){
			FermerGraphique();
			return EXIT_SUCCESS;
		}
	}
  return EXIT_SUCCESS;
}
