#ifndef PARTIE_1_JOUEUR
#define PARTIE_1_JOUEUR

void partie_un_joueur(int taille_tableau);

#endif
