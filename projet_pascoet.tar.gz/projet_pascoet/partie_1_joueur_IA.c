#include <stdlib.h>
#include <stdio.h>
#include <time.h>


void IA_aleatoire(int* joueur2_x, int* joueur2_y, int modulo){
	*joueur2_x = (rand()%modulo);
	*joueur2_y = (rand()%modulo);
}

void IA_deplacement(int* joueur2_x, int* joueur2_y, int tab[][9], int taille_tableau){
	int pos_x = (*joueur2_x), pos_y = (*joueur2_y), compteur = 0;

		while(compteur != 2){
			compteur = 0;
			*joueur2_x = pos_x;
			*joueur2_y = pos_y;
			*joueur2_x = *joueur2_x+(rand()%3)-1;
			*joueur2_y = *joueur2_y+(rand()%3)-1;
			if (*joueur2_y < taille_tableau && *joueur2_y >= 0 && tab[*joueur2_x][*joueur2_y] == 0)
				compteur++;
			if (*joueur2_x < taille_tableau && *joueur2_x >= 0 && tab[*joueur2_x][*joueur2_y] == 0)
				compteur++;
		}
		printf("tabxy %d %d %d\n",tab[*joueur2_x][*joueur2_y], *joueur2_x, *joueur2_y);

	tab[pos_x][pos_y] = 0;
	tab[*joueur2_x][*joueur2_y] = 8;
}
void IA_cocher_case(int joueur1_x, int joueur1_y, int game_over_joueur1, int tab[][9], int taille_tableau){
	int pos_x = joueur1_x, pos_y = joueur1_y, compteur = 0;
	if(game_over_joueur1 != 0){
		while(compteur != 2){
			compteur = 0;
			joueur1_x = pos_x;
			joueur1_y = pos_y;
			joueur1_x = joueur1_x+(rand()%3)-1;
			joueur1_y = joueur1_y+(rand()%3)-1;
			if (joueur1_y < taille_tableau && joueur1_y >= 0 && tab[joueur1_x][joueur1_y] == 0)
				compteur++;
			if (joueur1_x < taille_tableau && joueur1_x >= 0 && tab[joueur1_x][joueur1_y] == 0)
				compteur++;
		}
		printf("1x 1y %d %d \n", joueur1_x, joueur1_y);
		tab[joueur1_x][joueur1_y] = 1;
		return;
	}
	while(tab[joueur1_x][joueur1_y] != 0){
		IA_aleatoire(&joueur1_x, &joueur1_y, taille_tableau);
	}
	tab[joueur1_x][joueur1_y] = 1;
	return;
}
